import TableHOC from "./TableHOC.tsx";

function DashboardTable() {
  return <div>DashboardTable</div>;
}

export default DashboardTable;
