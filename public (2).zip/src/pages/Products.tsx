function Products() {
  return (
    <main className="dashboard">
      <div className="bar"></div>
    </main>
  );
}

export default Products;
