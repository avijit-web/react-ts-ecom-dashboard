import React from "react";
import AdminSidebar from "../components/AdminSidebar";

const Tranactions = () => {
  return (
    <div className="adminContainer">
      <AdminSidebar />

      <main>abcd</main>

      {/* main */}
    </div>
  );
};

export default Tranactions;
