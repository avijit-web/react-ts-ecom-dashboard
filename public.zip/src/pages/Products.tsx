import React from "react";
import AdminSidebar from "../components/AdminSidebar";

function Products() {
  return (
    <div className="adminContainer">
      <AdminSidebar />

      <main className="dashboard">
        <div className="bar"></div>
      </main>

      {/* main */}
    </div>
  );
}

export default Products;
