import { FaRegBell } from "react-icons/fa";
import AdminSidebar from "../components/AdminSidebar";
import { BsSearch } from "react-icons/bs";
import { HiTrendingDown, HiTrendingUp } from "react-icons/hi";

function Dashboard() {
  return (
    <div className="adminContainer">
      <AdminSidebar />

      <main className="dashboard">
        <div className="bar">
          <BsSearch />
          <input type="text" placeholder="Search for data , users , docs," />
          <FaRegBell />
          <img src={"https://i.pravatar.cc/300"} alt="User" />
        </div>
        <section className="widgetcontainer">
          <WidgetItem
            percent={40}
            amount={true}
            value={340000}
            heading="Revenue"
            color="rgb(0,115,255)"
          />
          <WidgetItem
            percent={-14}
            value={340000}
            heading="Users"
            color="red"
          />
          <WidgetItem
            percent={70}
            amount={true}
            value={23000}
            heading="Transactions"
            color="rgb(255,196,0)"
          />
          <WidgetItem
            percent={30}
            value={1000}
            heading="Products"
            color="rgb(76,0,255)"
          />
        </section>
      </main>

      {/* main */}
    </div>
  );
}

interface WidgetItemProps {
  heading: string;
  value: number;
  percent: number;
  color: string;
  amount?: boolean;
}

const WidgetItem = ({
  heading,
  value,
  percent,
  color,
  amount,
}: WidgetItemProps) => {
  return (
    <article className="widget">
      <div className="widgetInfo">
        <p>{heading}</p>
        <h4>{amount ? `$${value}` : value}</h4>
        {percent > 0 ? (
          <span className="green">
            <HiTrendingUp /> +{percent}%
          </span>
        ) : (
          <span className="red">
            <HiTrendingDown /> {percent}%
          </span>
        )}
      </div>

      <div
        className="widgetCircle"
        style={{
          background: `conic-gradient(${color} ${(Math.abs(percent) / 100) * 360}deg,rgb(255,255,255) 0 )`,
        }}
      >
        <span color={color}>{percent}%</span>
      </div>
    </article>
  );
};

export default Dashboard;
